import os
import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto, InputMediaVideo, InputMediaAudio, InputFile
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from datetime import datetime, timedelta
import pytz

logging.basicConfig(level=logging.INFO)
TOKEN = "7857620688:AAFQA0pTMpUyxJRl4QgPPrDStlb4p5X0koo"
if not TOKEN or TOKEN.startswith("YOUR_BOT_TOKEN"):
    raise ValueError("Please set a valid bot token!")

user_drafts = {}
scheduled_posts = []
channel_id = '@SenpaiDubs'  # Kanal @username yoki -100... ko‘rinishida

def get_main_keyboard():
    keyboard = [
        [InlineKeyboardButton("📝 Yangi post", callback_data="new_post")],
        [InlineKeyboardButton("📅 Rejalashtirilgan postlar", callback_data="scheduled")],
        [InlineKeyboardButton("❓ Yordam", callback_data="help")]
    ]
    return InlineKeyboardMarkup(keyboard)

# /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Post botiga xush kelibsiz!\n\n"
        "📝 Post yaratish uchun «Yangi post» tugmasini bosing.\n"
        "📅 Rejalashtirilgan postlarni ko'rish uchun «Rejalashtirilgan postlar»ni tanlang.",
        reply_markup=get_main_keyboard()
    )

# /post
async def post(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_drafts[user_id] = {"text": "", "entities": [], "media": None, "buttons": []}
    await update.message.reply_text("Post matnini yuboring (stil bilan):")

# Matn va format
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in user_drafts:
        user_drafts[user_id]["text"] = update.message.text
        user_drafts[user_id]["entities"] = update.message.entities or []
        await update.message.reply_text("Tugma qo‘shish uchun /addbutton. Yoki /media yuboring.")

# Media qabul qilish
async def handle_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    draft = user_drafts.get(user_id)
    if not draft:
        await update.message.reply_text("Avval /post buyrug‘ini bering.")
        return

    if update.message.photo:
        file = await update.message.photo[-1].get_file()
        draft["media"] = {"type": "photo", "file_id": file.file_id}
    elif update.message.video:
        file = await update.message.video.get_file()
        draft["media"] = {"type": "video", "file_id": file.file_id}
    elif update.message.audio:
        file = await update.message.audio.get_file()
        draft["media"] = {"type": "audio", "file_id": file.file_id}
    elif update.message.document:
        file = await update.message.document.get_file()
        draft["media"] = {"type": "document", "file_id": file.file_id}

    await update.message.reply_text("Media saqlandi. /preview yoki /schedule")

# /addbutton
async def add_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Tugma format: `Nomi - https://link.com` yoki `Nomi - callback_data`")

# Tugma matni
async def button_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    line = update.message.text
    if " - " in line:
        text, data = line.split(" - ", 1)
        button = InlineKeyboardButton(text.strip(),
                                      url=data.strip() if data.startswith("http") else None,
                                      callback_data=None if data.startswith("http") else data.strip())
        user_drafts[user_id]["buttons"].append([button])
        await update.message.reply_text("Tugma qo‘shildi. Yana qo‘shing yoki /preview bosing.")

# /preview
async def preview(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    draft = user_drafts.get(user_id)
    if not draft:
        await update.message.reply_text("Hech qanday post yo‘q.")
        return

    keyboard = InlineKeyboardMarkup(draft["buttons"]) if draft["buttons"] else None

    if draft["media"]:
        media_type = draft["media"]["type"]
        file_id = draft["media"]["file_id"]
        send_func = {
            "photo": context.bot.send_photo,
            "video": context.bot.send_video,
            "audio": context.bot.send_audio,
            "document": context.bot.send_document
        }.get(media_type)
        await send_func(chat_id=update.effective_chat.id,
                        caption=draft["text"],
                        caption_entities=draft["entities"],
                        reply_markup=keyboard)
    else:
        await update.message.reply_text(draft["text"], entities=draft["entities"], reply_markup=keyboard)

    await update.message.reply_text("Bu preview. /send yoki /schedule buyrug‘i bilan yakunlang.")

# /send
async def send(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    draft = user_drafts.get(user_id)
    if not draft:
        await update.message.reply_text("Post topilmadi.")
        return

    keyboard = InlineKeyboardMarkup(draft["buttons"]) if draft["buttons"] else None
    if draft["media"]:
        media_type = draft["media"]["type"]
        file_id = draft["media"]["file_id"]
        send_func = {
            "photo": context.bot.send_photo,
            "video": context.bot.send_video,
            "audio": context.bot.send_audio,
            "document": context.bot.send_document
        }.get(media_type)
        await send_func(chat_id=channel_id,
                        caption=draft["text"],
                        caption_entities=draft["entities"],
                        reply_markup=keyboard,
                        disable_notification=True)
    else:
        await context.bot.send_message(chat_id=channel_id,
                                       text=draft["text"],
                                       entities=draft["entities"],
                                       reply_markup=keyboard,
                                       disable_notification=True)
    await update.message.reply_text("Post yuborildi.")
    user_drafts.pop(user_id)

# /schedule DD-MM-YYYY HH:MM
async def schedule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    draft = user_drafts.get(user_id)
    if not draft:
        await update.message.reply_text("Post yo‘q.")
        return
    try:
        args = update.message.text.split(" ", 1)[1]
        dt = datetime.strptime(args, "%d-%m-%Y %H:%M")
        tz = pytz.timezone("Asia/Tashkent")
        scheduled_time = tz.localize(dt)
        scheduled_posts.append({"user_id": user_id, "post": draft, "time": scheduled_time})
        await update.message.reply_text(f"Post rejalashtirildi: {scheduled_time}")
        user_drafts.pop(user_id)
    except Exception as e:
        await update.message.reply_text("Format noto‘g‘ri. Misol: /schedule 18-04-2025 16:30")

# /list
async def list_scheduled(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = "Rejalashtirilgan postlar:\n"
    for i, item in enumerate(scheduled_posts):
        t = item["time"].strftime("%d-%m-%Y %H:%M")
        text += f"{i+1}. {t}\n"
    await update.message.reply_text(text if scheduled_posts else "Hech narsa yo‘q.")

# Postlarni tekshirib yuboruvchi background loop
async def scheduler(app: Application):
    while True:
        now = datetime.now(pytz.timezone("Asia/Tashkent"))
        for post in scheduled_posts[:]:
            if post["time"] <= now:
                data = post["post"]
                keyboard = InlineKeyboardMarkup(data["buttons"]) if data["buttons"] else None
                try:
                    if data["media"]:
                        media_type = data["media"]["type"]
                        file_id = data["media"]["file_id"]
                        send_func = {
                            "photo": app.bot.send_photo,
                            "video": app.bot.send_video,
                            "audio": app.bot.send_audio,
                            "document": app.bot.send_document
                        }.get(media_type)
                        await send_func(chat_id=channel_id,
                                        caption=data["text"],
                                        caption_entities=data["entities"],
                                        reply_markup=keyboard,
                                        disable_notification=True)
                    else:
                        await app.bot.send_message(chat_id=channel_id,
                                                   text=data["text"],
                                                   entities=data["entities"],
                                                   reply_markup=keyboard,
                                                   disable_notification=True)
                except Exception as e:
                    logging.error(f"Error sending scheduled post: {e}")
                scheduled_posts.remove(post)
        await asyncio.sleep(30)

# Callback tugmalar
async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data == "new_post":
        await query.message.reply_text("Post yaratish uchun /post buyrug'ini bering.")
    elif query.data == "scheduled":
        await list_scheduled(update, context)
    elif query.data == "help":
        await query.message.reply_text("Yordam matni bu yerda bo'ladi.")




def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("post", post))
    app.add_handler(CommandHandler("addbutton", add_button))
    app.add_handler(CommandHandler("preview", preview))
    app.add_handler(CommandHandler("send", send))
    app.add_handler(CommandHandler("schedule", schedule))
    app.add_handler(CommandHandler("list", list_scheduled))
    app.add_handler(CallbackQueryHandler(callback_handler))

    app.add_handler(MessageHandler(filters.TEXT & filters.Regex(" - "), button_text))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.PHOTO | filters.VIDEO | filters.AUDIO | filters.Document.ALL, handle_media))

    app.job_queue.run_once(lambda *_: asyncio.create_task(scheduler(app)), 1)

    app.run_polling()

if __name__ == "__main__":
    main()